export default function MaintenancePage() {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Kado Bajo — Coming Back Soon</title>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet" />
        <style dangerouslySetInnerHTML={{ __html: `
          *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
          body { font-family: 'DM Sans', sans-serif; background: #0D1117; color: white; min-height: 100vh; display: flex; align-items: center; justify-content: center; overflow: hidden; }

          .bg {
            position: fixed; inset: 0; z-index: 0;
            background: radial-gradient(ellipse at 20% 50%, rgba(45,63,143,0.35) 0%, transparent 60%),
                        radial-gradient(ellipse at 80% 20%, rgba(27,42,107,0.25) 0%, transparent 50%),
                        radial-gradient(ellipse at 60% 80%, rgba(45,63,143,0.15) 0%, transparent 50%),
                        #0D1117;
          }
          .grid-overlay {
            position: fixed; inset: 0; z-index: 0;
            background-image: linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px);
            background-size: 48px 48px;
          }
          .noise {
            position: fixed; inset: 0; z-index: 0; opacity: 0.04;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E");
          }

          .wrap { position: relative; z-index: 10; text-align: center; padding: 40px 24px; max-width: 600px; width: 100%; }

          /* Logo */
          .logo-ring {
            display: inline-block; margin-bottom: 40px;
            animation: float 4s ease-in-out infinite;
          }
          .logo-img {
            width: 120px; height: 120px; border-radius: 50%; object-fit: cover;
            box-shadow: 0 0 0 1px rgba(255,255,255,0.1), 0 0 40px rgba(45,63,143,0.6), 0 0 80px rgba(45,63,143,0.3);
          }

          /* Status pill */
          .status-pill {
            display: inline-flex; align-items: center; gap: 8px;
            background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12);
            border-radius: 99px; padding: 6px 16px; margin-bottom: 28px;
            backdrop-filter: blur(8px);
          }
          .status-dot { width: 6px; height: 6px; border-radius: 50%; background: #F59E0B; animation: blink 2s ease-in-out infinite; flex-shrink: 0; }
          .status-text { font-size: 11px; font-weight: 700; color: #F59E0B; letter-spacing: 2px; text-transform: uppercase; }

          /* Heading */
          h1 { font-family: 'Playfair Display', serif; font-size: clamp(36px, 6vw, 60px); font-weight: 700; line-height: 1.1; margin-bottom: 16px; }
          h1 em { font-style: italic; color: #7C9EF8; }
          .subtitle { font-size: 16px; color: rgba(255,255,255,0.5); line-height: 1.7; max-width: 440px; margin: 0 auto 40px; font-weight: 300; }

          /* Divider */
          .divider { width: 48px; height: 2px; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent); margin: 0 auto 40px; }

          /* Info cards */
          .cards { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; margin-bottom: 40px; }
          .card {
            background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08);
            border-radius: 14px; padding: 16px 20px; text-align: left; min-width: 160px;
            backdrop-filter: blur(8px);
          }
          .card-icon { font-size: 20px; margin-bottom: 8px; }
          .card-title { font-size: 12px; font-weight: 700; color: rgba(255,255,255,0.9); margin-bottom: 3px; }
          .card-sub { font-size: 11px; color: rgba(255,255,255,0.35); }

          /* WA button */
          .wa-btn {
            display: inline-flex; align-items: center; gap: 10px;
            background: linear-gradient(135deg, #16A34A, #15803D);
            color: white; text-decoration: none; padding: 14px 28px;
            border-radius: 12px; font-size: 14px; font-weight: 700;
            box-shadow: 0 4px 20px rgba(22,163,74,0.3);
            transition: all 0.2s;
          }
          .wa-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(22,163,74,0.4); }

          .footer-note { margin-top: 32px; font-size: 12px; color: rgba(255,255,255,0.2); }
          .footer-note a { color: rgba(255,255,255,0.35); text-decoration: none; }

          @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }
          @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.3} }
          @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
          .wrap > * { animation: fadeUp 0.6s ease forwards; opacity: 0; }
          .wrap > *:nth-child(1){animation-delay:0.1s}
          .wrap > *:nth-child(2){animation-delay:0.2s}
          .wrap > *:nth-child(3){animation-delay:0.3s}
          .wrap > *:nth-child(4){animation-delay:0.4s}
          .wrap > *:nth-child(5){animation-delay:0.5s}
          .wrap > *:nth-child(6){animation-delay:0.6s}
          .wrap > *:nth-child(7){animation-delay:0.7s}
          .wrap > *:nth-child(8){animation-delay:0.8s}
        `}} />
      </head>
      <body>
        <div className="bg" />
        <div className="grid-overlay" />
        <div className="noise" />

        <div className="wrap">
          <div className="logo-ring">
            <img src="/logo.png" alt="Kado Bajo" className="logo-img" />
          </div>

          <div className="status-pill">
            <span className="status-dot" />
            <span className="status-text">Under Maintenance</span>
          </div>

          <h1>We're making things<br /><em>better for you</em></h1>

          <p className="subtitle">
            Kado Bajo sedang dalam pemeliharaan. Kami akan segera kembali dengan pengalaman yang lebih baik.
          </p>

          <div className="divider" />

          <div className="cards">
            <div className="card">
              <div className="card-icon">✈️</div>
              <div className="card-title">Airport Pickup</div>
              <div className="card-sub">Tetap tersedia</div>
            </div>
            <div className="card">
              <div className="card-icon">🎁</div>
              <div className="card-title">Personal Shopper</div>
              <div className="card-sub">Hubungi via WhatsApp</div>
            </div>
            <div className="card">
              <div className="card-icon">⏰</div>
              <div className="card-title">Segera Kembali</div>
              <div className="card-sub">Dalam waktu singkat</div>
            </div>
          </div>

          <a href="https://wa.me/6282146970988?text=Hi%20Kado%20Bajo!%20I%27d%20like%20to%20order%20souvenirs." className="wa-btn">
            <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
            </svg>
            Order via WhatsApp
          </a>

          <p className="footer-note">
            © 2026 Kado Bajo · Labuan Bajo, NTT &nbsp;·&nbsp;
            <a href="https://wa.me/6282146970988">+62 821 4697 0988</a>
          </p>
        </div>
      </body>
    </html>
  );
}

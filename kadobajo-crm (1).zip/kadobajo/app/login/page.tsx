'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (res.ok) { router.push('/dashboard'); router.refresh(); }
      else setError('Email atau password salah.');
    } catch { setError('Terjadi kesalahan. Coba lagi.'); }
    finally { setLoading(false); }
  }

  return (
    <div className="login-root">
      <div style={{
        position: 'fixed', inset: 0,
        background: 'radial-gradient(ellipse at top, rgba(45,63,143,0.06) 0%, transparent 60%)',
        pointerEvents: 'none',
      }} />

      <div className="login-wrap">
        <div className="login-logo">
          <div className="logo-pulse">
            <img src="/logo.png" alt="Kado Bajo" />
          </div>
          <h1>Kado Bajo</h1>
          <p>Admin CRM Dashboard</p>
        </div>

        <div className="login-card">
          <div className="login-card-title serif">Masuk ke Dashboard</div>
          <form onSubmit={handleSubmit}>
            <div className="login-field">
              <label className="login-label">Email</label>
              <input type="email" className="login-input" value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                placeholder="admin@kadobajo.com" autoComplete="email" />
            </div>
            <div className="login-field">
              <label className="login-label">Password</label>
              <input type="password" className="login-input" value={form.password}
                onChange={e => setForm({ ...form, password: e.target.value })}
                placeholder="••••••" autoComplete="current-password" />
            </div>
            {error && <div className="login-error">{error}</div>}
            <button type="submit" className="login-btn" disabled={loading}>
              {loading ? <><span className="spin" />Masuk…</> : 'Masuk'}
            </button>
          </form>
        </div>

        <a href="https://kadobajo.id" className="login-back">← Kembali ke kadobajo.id</a>
      </div>
    </div>
  );
}

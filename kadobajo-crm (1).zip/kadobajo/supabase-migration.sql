-- ============================================================
-- FRESH INSTALL
-- ============================================================
create table if not exists public.customers (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  email         text not null default '',
  phone         text not null unique,
  country       text,
  city          text,
  status        text not null default 'new'
                  check (status in ('new','contacted','negotiation','deal','lost')),
  source        text not null default 'landing_page',
  utm_source    text,
  utm_medium    text,
  utm_campaign  text,
  utm_content   text,
  device        text,
  tag           text,
  notes         text,
  value         integer,
  created_at    timestamptz not null default now()
);

-- ============================================================
-- EXISTING TABLE — run this if table already exists
-- ============================================================
alter table public.customers add column if not exists country      text;
alter table public.customers add column if not exists city         text;
alter table public.customers add column if not exists utm_source   text;
alter table public.customers add column if not exists utm_medium   text;
alter table public.customers add column if not exists utm_campaign text;
alter table public.customers add column if not exists utm_content  text;
alter table public.customers add column if not exists device       text;

-- Indexes
create index if not exists customers_phone_idx    on public.customers (phone);
create index if not exists customers_status_idx   on public.customers (status);
create index if not exists customers_country_idx  on public.customers (country);
create index if not exists customers_source_idx   on public.customers (utm_source);

-- RLS
alter table public.customers enable row level security;
create policy "Allow anon read"   on public.customers for select using (true);
create policy "Allow anon insert" on public.customers for insert with check (true);
create policy "Allow anon update" on public.customers for update using (true);

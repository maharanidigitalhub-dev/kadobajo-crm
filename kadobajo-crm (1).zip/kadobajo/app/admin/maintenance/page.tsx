export default function AdminMaintenancePage() {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Kado Bajo Admin — Maintenance</title>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet" />
        <style dangerouslySetInnerHTML={{ __html: `
          *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
          body { font-family: 'DM Sans', sans-serif; background: #F8F9FF; color: #111827; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px; }

          .wrap { text-align: center; max-width: 480px; width: 100%; }

          .logo-wrap { margin-bottom: 32px; }
          .logo-img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; box-shadow: 0 8px 32px rgba(45,63,143,0.2); }

          .badge {
            display: inline-flex; align-items: center; gap: 7px;
            background: #FEF3C7; border: 1.5px solid #FDE68A;
            border-radius: 99px; padding: 5px 14px; margin-bottom: 24px;
          }
          .badge-dot { width: 6px; height: 6px; border-radius: 50%; background: #F59E0B; animation: blink 2s ease-in-out infinite; }
          .badge-text { font-size: 11px; font-weight: 700; color: #B45309; letter-spacing: 1.5px; text-transform: uppercase; }

          .card {
            background: white; border: 1.5px solid #E8ECF8; border-radius: 24px;
            padding: 40px 32px; box-shadow: 0 4px 24px rgba(45,63,143,0.08);
          }

          h1 { font-family: 'Playfair Display', serif; font-size: 26px; color: #111827; margin-bottom: 12px; }
          .desc { font-size: 14px; color: #6B7280; line-height: 1.7; margin-bottom: 28px; }

          .progress-wrap { margin-bottom: 28px; }
          .progress-label { display: flex; justify-content: space-between; font-size: 12px; color: #9CA3AF; margin-bottom: 8px; }
          .progress-track { height: 6px; background: #F1F5F9; border-radius: 99px; overflow: hidden; }
          .progress-fill { height: 100%; border-radius: 99px; background: linear-gradient(90deg, #2D3F8F, #6366F1); animation: load 2.5s ease-in-out infinite; }

          .items { display: flex; flex-direction: column; gap: 10px; margin-bottom: 28px; text-align: left; }
          .item { display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: 12px; background: #F8F9FF; }
          .item-icon { font-size: 16px; flex-shrink: 0; }
          .item-text { font-size: 13px; color: #374151; font-weight: 500; }
          .item-check { margin-left: auto; font-size: 14px; flex-shrink: 0; }

          .contact-box { background: #F0F3FD; border-radius: 12px; padding: 14px 18px; font-size: 13px; color: #374151; }
          .contact-box strong { color: #1B2A6B; }
          .contact-box a { color: #2D3F8F; font-weight: 600; text-decoration: none; }

          .footer { margin-top: 24px; font-size: 12px; color: #CBD5E1; }

          @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.3} }
          @keyframes load { 0%{width:0%;margin-left:0} 50%{width:70%;margin-left:0} 75%{width:70%;margin-left:30%} 100%{width:0%;margin-left:100%} }
          @keyframes fadeUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
          .wrap > * { animation: fadeUp 0.5s ease forwards; opacity: 0; }
          .wrap > *:nth-child(1){animation-delay:0.1s}
          .wrap > *:nth-child(2){animation-delay:0.2s}
          .wrap > *:nth-child(3){animation-delay:0.25s}
          .wrap > *:nth-child(4){animation-delay:0.35s}
        `}} />
      </head>
      <body>
        <div className="wrap">
          <div className="logo-wrap">
            <img src="/logo.png" alt="Kado Bajo" className="logo-img" />
          </div>

          <div className="badge">
            <span className="badge-dot" />
            <span className="badge-text">System Maintenance</span>
          </div>

          <div className="card">
            <h1>Admin Dashboard</h1>
            <p className="desc">
              Sistem sedang dalam pemeliharaan.<br />
              Dashboard akan kembali online dalam waktu singkat.
            </p>

            <div className="progress-wrap">
              <div className="progress-label">
                <span>Maintenance in progress</span>
                <span>Please wait…</span>
              </div>
              <div className="progress-track">
                <div className="progress-fill" />
              </div>
            </div>

            <div className="items">
              {[
                { icon: '🗄️', text: 'Database update', done: true },
                { icon: '🔧', text: 'System configuration', done: true },
                { icon: '🚀', text: 'Performance improvements', done: false },
                { icon: '✅', text: 'Final testing & deployment', done: false },
              ].map((item, i) => (
                <div key={i} className="item">
                  <span className="item-icon">{item.icon}</span>
                  <span className="item-text">{item.text}</span>
                  <span className="item-check">{item.done ? '✅' : '⏳'}</span>
                </div>
              ))}
            </div>

            <div className="contact-box">
              Butuh akses darurat? Hubungi developer:<br />
              <a href="mailto:admin@kadobajo.com">admin@kadobajo.com</a>
            </div>
          </div>

          <p className="footer">© 2026 Kado Bajo CRM · Internal Use Only</p>
        </div>
      </body>
    </html>
  );
}

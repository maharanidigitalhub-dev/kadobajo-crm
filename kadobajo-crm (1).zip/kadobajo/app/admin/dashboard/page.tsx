import { getAllCustomers, getRecentCustomers } from '@/lib/customers';
import { Customer, CustomerStatus } from '@/types/customer';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

const STATUS_ORDER: CustomerStatus[] = ['new', 'contacted', 'negotiation', 'deal', 'lost'];

const STATUS_META: Record<CustomerStatus, { label: string; color: string; light: string; dot: string }> = {
  new:         { label: 'New Lead',     color: '#6366F1', light: '#EEF2FF', dot: '#6366F1' },
  contacted:   { label: 'Contacted',    color: '#0EA5E9', light: '#E0F2FE', dot: '#0EA5E9' },
  negotiation: { label: 'Negotiation',  color: '#F59E0B', light: '#FEF3C7', dot: '#F59E0B' },
  deal:        { label: 'Deal Closed',  color: '#10B981', light: '#D1FAE5', dot: '#10B981' },
  lost:        { label: 'Lost',         color: '#F43F5E', light: '#FFE4E6', dot: '#F43F5E' },
};

function countByStatus(customers: Customer[]) {
  return STATUS_ORDER.reduce((acc, s) => {
    acc[s] = customers.filter(c => c.status === s).length;
    return acc;
  }, {} as Record<CustomerStatus, number>);
}

function getInitials(name: string) {
  return name.split(' ').slice(0, 2).map(n => n[0]).join('').toUpperCase();
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const m = Math.floor(diff / 60000);
  const h = Math.floor(diff / 3600000);
  const d = Math.floor(diff / 86400000);
  if (m < 1) return 'Just now';
  if (m < 60) return `${m}m ago`;
  if (h < 24) return `${h}h ago`;
  return `${d}d ago`;
}

export default async function DashboardPage() {
  let all: Customer[] = [];
  let recent: Customer[] = [];
  let fetchError = false;

  try {
    [all, recent] = await Promise.all([getAllCustomers(), getRecentCustomers(6)]);
  } catch { fetchError = true; }

  const counts = countByStatus(all);
  const revenue = all.reduce((sum, c) => sum + (c.value ?? 0), 0);
  const conversionRate = all.length > 0 ? ((counts.deal / all.length) * 100).toFixed(1) : '0.0';
  const activeLeads = counts.new + counts.contacted + counts.negotiation;

  return (
    <div style={{ fontFamily: "'DM Sans', sans-serif", minHeight: '100vh', background: '#F8F9FF', padding: '32px 28px' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600;700&display=swap');
        @keyframes fadeUp { from { opacity:0; transform:translateY(12px); } to { opacity:1; transform:translateY(0); } }
        @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }
        .dash-card { animation: fadeUp 0.5s ease forwards; opacity: 0; }
        .dash-card:nth-child(1){animation-delay:0.05s}
        .dash-card:nth-child(2){animation-delay:0.1s}
        .dash-card:nth-child(3){animation-delay:0.15s}
        .dash-card:nth-child(4){animation-delay:0.2s}
        .stat-card { transition: transform 0.2s, box-shadow 0.2s; }
        .stat-card:hover { transform: translateY(-2px); box-shadow: 0 8px 32px rgba(45,63,143,0.12) !important; }
        .activity-row { transition: background 0.15s; }
        .activity-row:hover { background: #F0F3FD !important; }
        .live-dot { animation: pulse 2s ease-in-out infinite; }
        .progress-bar { transition: width 1s cubic-bezier(0.4, 0, 0.2, 1); }
        .serif { font-family: 'Playfair Display', serif; }
      `}</style>

      {/* ── HEADER ── */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 32, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
            <h1 className="serif" style={{ fontSize: 26, fontWeight: 700, color: '#0F172A', margin: 0 }}>Dashboard</h1>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, background: '#DCFCE7', borderRadius: 20, padding: '3px 10px' }}>
              <span className="live-dot" style={{ width: 6, height: 6, borderRadius: '50%', background: '#16A34A', display: 'inline-block' }} />
              <span style={{ fontSize: 11, fontWeight: 700, color: '#16A34A', letterSpacing: '0.5px' }}>LIVE</span>
            </div>
          </div>
          <p style={{ fontSize: 13, color: '#94A3B8', margin: 0 }}>
            {new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
        <Link href="/admin/customers"
          style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'linear-gradient(135deg, #2D3F8F, #1B2A6B)', color: 'white', textDecoration: 'none', padding: '10px 20px', borderRadius: 12, fontSize: 13, fontWeight: 600 }}>
          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          All Customers
        </Link>
      </div>

      {/* Error Banner */}
      {fetchError && (
        <div style={{ background: '#FEF2F2', border: '1.5px solid #FECACA', borderRadius: 14, padding: '14px 18px', marginBottom: 24 }}>
          <p style={{ fontSize: 13, fontWeight: 600, color: '#DC2626', margin: '0 0 4px' }}>⚠️ Database connection failed</p>
          <p style={{ fontSize: 12, color: '#9CA3AF', margin: 0 }}>Check SUPABASE_URL and SUPABASE_ANON_KEY in Vercel settings.</p>
        </div>
      )}

      {/* ── KPI CARDS ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>

        {/* Total Leads */}
        <div className="stat-card dash-card" style={{ background: 'linear-gradient(135deg, #2D3F8F 0%, #1B2A6B 100%)', borderRadius: 20, padding: '22px 20px', boxShadow: '0 4px 20px rgba(45,63,143,0.25)', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: -20, right: -20, width: 80, height: 80, borderRadius: '50%', background: 'rgba(255,255,255,0.08)' }} />
          <div style={{ position: 'absolute', bottom: -30, right: 10, width: 100, height: 100, borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }} />
          <p style={{ fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.6)', textTransform: 'uppercase', letterSpacing: '1px', margin: '0 0 12px' }}>Total Leads</p>
          <p style={{ fontSize: 36, fontWeight: 700, color: 'white', margin: '0 0 4px', lineHeight: 1 }}>{all.length}</p>
          <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', margin: 0 }}>{activeLeads} aktif saat ini</p>
        </div>

        {/* Deal Closed */}
        <div className="stat-card dash-card" style={{ background: 'white', borderRadius: 20, padding: '22px 20px', border: '1.5px solid #E8ECF8', boxShadow: '0 2px 8px rgba(45,63,143,0.05)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '1px', margin: 0 }}>Deal Closed</p>
            <div style={{ width: 32, height: 32, borderRadius: 10, background: '#D1FAE5', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>🤝</div>
          </div>
          <p style={{ fontSize: 36, fontWeight: 700, color: '#0F172A', margin: '0 0 4px', lineHeight: 1 }}>{counts.deal}</p>
          <p style={{ fontSize: 12, color: '#10B981', fontWeight: 600, margin: 0 }}>Konversi {conversionRate}%</p>
        </div>

        {/* Active Pipeline */}
        <div className="stat-card dash-card" style={{ background: 'white', borderRadius: 20, padding: '22px 20px', border: '1.5px solid #E8ECF8', boxShadow: '0 2px 8px rgba(45,63,143,0.05)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '1px', margin: 0 }}>In Pipeline</p>
            <div style={{ width: 32, height: 32, borderRadius: 10, background: '#FEF3C7', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>⚡</div>
          </div>
          <p style={{ fontSize: 36, fontWeight: 700, color: '#0F172A', margin: '0 0 4px', lineHeight: 1 }}>{activeLeads}</p>
          <p style={{ fontSize: 12, color: '#F59E0B', fontWeight: 600, margin: 0 }}>{counts.negotiation} dalam negosiasi</p>
        </div>

        {/* Revenue */}
        <div className="stat-card dash-card" style={{ background: 'white', borderRadius: 20, padding: '22px 20px', border: '1.5px solid #E8ECF8', boxShadow: '0 2px 8px rgba(45,63,143,0.05)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '1px', margin: 0 }}>Est. Revenue</p>
            <div style={{ width: 32, height: 32, borderRadius: 10, background: '#EEF2FF', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>💰</div>
          </div>
          <p style={{ fontSize: 28, fontWeight: 700, color: '#0F172A', margin: '0 0 4px', lineHeight: 1 }}>
            {revenue > 0 ? `Rp ${(revenue / 1000000).toFixed(1)}M` : 'Rp —'}
          </p>
          <p style={{ fontSize: 12, color: '#94A3B8', margin: 0 }}>dari {counts.deal} deal</p>
        </div>
      </div>

      {/* ── MAIN GRID ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 20 }}>

        {/* ── PIPELINE FUNNEL ── */}
        <div style={{ background: 'white', borderRadius: 20, padding: '24px', border: '1.5px solid #E8ECF8', boxShadow: '0 2px 8px rgba(45,63,143,0.04)' }}>
          <div style={{ marginBottom: 20 }}>
            <h2 className="serif" style={{ fontSize: 17, fontWeight: 700, color: '#0F172A', margin: '0 0 2px' }}>Sales Pipeline</h2>
            <p style={{ fontSize: 12, color: '#94A3B8', margin: 0 }}>Distribusi lead berdasarkan status</p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {STATUS_ORDER.map((s, i) => {
              const meta = STATUS_META[s];
              const count = counts[s];
              const pct = all.length > 0 ? (count / all.length) * 100 : 0;
              const widths = [100, 80, 60, 45, 30];

              return (
                <div key={s}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 8, height: 8, borderRadius: '50%', background: meta.dot, flexShrink: 0 }} />
                      <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>{meta.label}</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontSize: 12, fontWeight: 700, color: meta.color, background: meta.light, padding: '2px 8px', borderRadius: 20 }}>{count}</span>
                      <span style={{ fontSize: 11, color: '#CBD5E1', width: 36, textAlign: 'right' }}>{pct.toFixed(0)}%</span>
                    </div>
                  </div>
                  <div style={{ height: 8, background: '#F1F5F9', borderRadius: 99, overflow: 'hidden' }}>
                    <div className="progress-bar" style={{
                      height: '100%', borderRadius: 99,
                      width: `${pct}%`,
                      background: `linear-gradient(90deg, ${meta.color}99, ${meta.color})`,
                      minWidth: count > 0 ? 8 : 0,
                    }} />
                  </div>
                </div>
              );
            })}
          </div>

          {all.length === 0 && !fetchError && (
            <div style={{ textAlign: 'center', padding: '32px 0', color: '#CBD5E1' }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>📭</div>
              <p style={{ fontSize: 13, margin: 0 }}>Belum ada lead masuk</p>
            </div>
          )}

          {/* Donut summary */}
          {all.length > 0 && (
            <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid #F1F5F9', display: 'flex', justifyContent: 'space-between' }}>
              {[
                { label: 'Win Rate', value: `${conversionRate}%`, color: '#10B981' },
                { label: 'Active', value: activeLeads, color: '#2D3F8F' },
                { label: 'Lost', value: counts.lost, color: '#F43F5E' },
              ].map(item => (
                <div key={item.label} style={{ textAlign: 'center' }}>
                  <p style={{ fontSize: 18, fontWeight: 700, color: item.color, margin: '0 0 2px' }}>{item.value}</p>
                  <p style={{ fontSize: 11, color: '#94A3B8', margin: 0 }}>{item.label}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── RECENT ACTIVITY ── */}
        <div style={{ background: 'white', borderRadius: 20, padding: '24px', border: '1.5px solid #E8ECF8', boxShadow: '0 2px 8px rgba(45,63,143,0.04)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
            <div>
              <h2 className="serif" style={{ fontSize: 17, fontWeight: 700, color: '#0F172A', margin: '0 0 2px' }}>Recent Leads</h2>
              <p style={{ fontSize: 12, color: '#94A3B8', margin: 0 }}>Lead terbaru yang masuk</p>
            </div>
            <Link href="/admin/customers"
              style={{ fontSize: 12, fontWeight: 600, color: '#2D3F8F', textDecoration: 'none', background: '#F0F3FD', padding: '6px 14px', borderRadius: 8 }}>
              Lihat semua →
            </Link>
          </div>

          {recent.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '48px 0' }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>🌊</div>
              <p style={{ fontSize: 14, color: '#94A3B8', margin: 0 }}>
                {fetchError ? 'Gagal memuat data.' : 'Belum ada lead. Share landing page-mu!'}
              </p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              {recent.map((c, i) => {
                const meta = STATUS_META[c.status];
                const initials = getInitials(c.name);
                const colors = [
                  ['#EEF2FF', '#2D3F8F'], ['#D1FAE5', '#065F46'], ['#FEF3C7', '#B45309'],
                  ['#FFE4E6', '#BE123C'], ['#E0F2FE', '#0369A1'], ['#F3E8FF', '#7E22CE'],
                ];
                const [avatarBg, avatarText] = colors[i % colors.length];

                return (
                  <div key={c.id} className="activity-row" style={{
                    display: 'flex', alignItems: 'center', gap: 12,
                    padding: '10px 12px', borderRadius: 12, cursor: 'default',
                  }}>
                    {/* Avatar */}
                    <div style={{
                      width: 40, height: 40, borderRadius: 12, flexShrink: 0,
                      background: avatarBg, display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 13, fontWeight: 700, color: avatarText,
                    }}>
                      {initials}
                    </div>

                    {/* Info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <p style={{ fontSize: 13, fontWeight: 600, color: '#0F172A', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {c.name}
                        </p>
                        {c.country && (
                          <span style={{ fontSize: 11, color: '#CBD5E1', flexShrink: 0 }}>{c.country}</span>
                        )}
                      </div>
                      <p style={{ fontSize: 11, color: '#94A3B8', margin: 0 }}>{c.phone}</p>
                    </div>

                    {/* Right side */}
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4, flexShrink: 0 }}>
                      <span style={{
                        fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 20,
                        background: meta.light, color: meta.color,
                      }}>
                        {meta.label}
                      </span>
                      {c.created_at && (
                        <span style={{ fontSize: 10, color: '#CBD5E1' }}>{timeAgo(c.created_at)}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ── QUICK ACTIONS ── */}
      <div style={{ marginTop: 20, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        {[
          {
            href: '/admin/customers',
            icon: '👥',
            title: 'Manage Customers',
            desc: 'Update status, tambah notes, export data',
            color: '#2D3F8F', bg: '#F0F3FD',
          },
          {
            href: '/admin/cms',
            icon: '✏️',
            title: 'Edit Landing Page',
            desc: 'Update teks hero, background, trust bar',
            color: '#7C3AED', bg: '#F5F3FF',
          },
          {
            href: `https://kadobajo.id`,
            icon: '🌐',
            title: 'View Live Site',
            desc: 'Buka kadobajo.id di tab baru',
            color: '#0369A1', bg: '#E0F2FE',
            external: true,
          },
        ].map(action => (
          <Link key={action.href} href={action.href}
            target={action.external ? '_blank' : undefined}
            rel={action.external ? 'noreferrer' : undefined}
            style={{
              display: 'flex', alignItems: 'center', gap: 14,
              background: 'white', border: '1.5px solid #E8ECF8',
              borderRadius: 16, padding: '16px 18px', textDecoration: 'none',
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLElement).style.borderColor = action.color + '44';
              (e.currentTarget as HTMLElement).style.boxShadow = `0 4px 16px ${action.color}15`;
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLElement).style.borderColor = '#E8ECF8';
              (e.currentTarget as HTMLElement).style.boxShadow = 'none';
            }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: action.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>
              {action.icon}
            </div>
            <div>
              <p style={{ fontSize: 13, fontWeight: 700, color: '#0F172A', margin: '0 0 2px' }}>{action.title}</p>
              <p style={{ fontSize: 11, color: '#94A3B8', margin: 0 }}>{action.desc}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

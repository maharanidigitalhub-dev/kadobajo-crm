'use client';

import { useEffect } from 'react';

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error('App error:', error);
  }, [error]);

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: '#F8F9FF', fontFamily: 'DM Sans, sans-serif', padding: 24,
    }}>
      <div style={{ textAlign: 'center', maxWidth: 400 }}>
        <img src="/logo.png" alt="Kado Bajo" width="64" height="64"
          style={{ borderRadius: '50%', marginBottom: 24, boxShadow: '0 4px 16px rgba(45,63,143,0.2)' }} />
        <h1 style={{ color: '#111827', fontSize: 20, fontWeight: 700, marginBottom: 8 }}>
          Terjadi Kesalahan
        </h1>
        <p style={{ color: '#6B7280', fontSize: 14, marginBottom: 24 }}>
          Halaman tidak bisa dimuat. Ini mungkin masalah sementara.
        </p>
        {error?.digest && (
          <p style={{ color: '#9CA3AF', fontSize: 11, marginBottom: 20, fontFamily: 'monospace' }}>
            Error ID: {error.digest}
          </p>
        )}
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <button onClick={reset}
            style={{ background: 'linear-gradient(135deg, #2D3F8F, #1B2A6B)', color: '#fff', border: 'none', padding: '10px 20px', borderRadius: 10, cursor: 'pointer', fontSize: 14, fontWeight: 600 }}>
            Coba Lagi
          </button>
          <a href="/"
            style={{ background: '#F3F4F6', color: '#374151', border: 'none', padding: '10px 20px', borderRadius: 10, cursor: 'pointer', fontSize: 14, fontWeight: 600, textDecoration: 'none', display: 'inline-flex', alignItems: 'center' }}>
            Ke Beranda
          </a>
        </div>
        <p style={{ color: '#9CA3AF', fontSize: 12, marginTop: 24 }}>
          Jika masalah berlanjut, periksa Vercel → Project → Logs
        </p>
      </div>
    </div>
  );
}

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? '';
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '';

interface SupabaseResponse<T> {
  data: T | null;
  error: { message: string; code?: string } | null;
}

async function supabaseRequest<T>(
  path: string,
  options: RequestInit = {}
): Promise<SupabaseResponse<T>> {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    console.error('[Supabase] Missing env vars');
    return { data: null, error: { message: 'Supabase env vars not configured' } };
  }

  const url = `${SUPABASE_URL}/rest/v1${path}`;
  const headers: Record<string, string> = {
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
    'Prefer': 'return=representation',
    ...(options.headers as Record<string, string>),
  };

  try {
    const res = await fetch(url, {
      ...options,
      headers,
      cache: 'no-store', // always fresh data
    });

    const text = await res.text();

    if (!res.ok) {
      console.error(`[Supabase] ${res.status} ${path}:`, text);
      let err: { message?: string; code?: string } = {};
      try { err = JSON.parse(text); } catch { err = { message: text }; }
      return { data: null, error: { message: err.message || res.statusText, code: err.code } };
    }

    const data = text ? JSON.parse(text) : [];
    console.log(`[Supabase] OK ${path} →`, Array.isArray(data) ? `${data.length} rows` : data);
    return { data, error: null };

  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Unknown error';
    console.error(`[Supabase] fetch error ${path}:`, msg);
    return { data: null, error: { message: msg } };
  }
}

export const supabase = {
  from: (table: string) => ({

    select: (
      columns = '*',
      opts: { order?: string; limit?: number; eq?: [string, string] } = {}
    ) => {
      // Supabase REST: /table?select=*&order=created_at.desc&limit=5
      const params = new URLSearchParams();
      params.set('select', columns);
      if (opts.order) params.set('order', opts.order);   // e.g. "created_at.desc"
      if (opts.limit)  params.set('limit',  String(opts.limit));
      if (opts.eq)     params.set(opts.eq[0], `eq.${opts.eq[1]}`);
      return supabaseRequest<unknown[]>(`/${table}?${params.toString()}`);
    },

    insert: (body: Record<string, unknown>) =>
      supabaseRequest<unknown[]>(`/${table}`, {
        method: 'POST',
        body: JSON.stringify(body),
      }),

    update: (body: Record<string, unknown>, match: Record<string, string>) => {
      const params = new URLSearchParams(
        Object.fromEntries(Object.entries(match).map(([k, v]) => [k, `eq.${v}`]))
      );
      return supabaseRequest<unknown[]>(`/${table}?${params.toString()}`, {
        method: 'PATCH',
        body: JSON.stringify(body),
      });
    },

    upsert: (body: Record<string, unknown>, onConflict: string) =>
      supabaseRequest<unknown[]>(`/${table}`, {
        method: 'POST',
        headers: {
          Prefer: `return=representation,resolution=ignore-duplicates,on_conflict=${onConflict}`,
        },
        body: JSON.stringify(body),
      }),
  }),
};
